import * as React from 'react';
import { Text,
 View, 
 StyleSheet,
 Image,
  TextInput,
  TouchableOpacity,
  } from 'react-native';
  import {Header} from 'react-native-elements';
import* as db from './components/localdb' ;
import PhonicSoundButton from'./components/SpeechSoundButton'
export default function App () {
  
    constructor(){
      super();
      this.state={
        text: '',
        chunks: [],
        sppechSounds: [];
      };
    }
render(){
  return (
    < View style={styles.container}>
    <Header
    backgroundColor= {'#FFFFFF'}
    centerComponent={{
      text: 'Text to Speech Converter',
      style: {color: '#00FFFF' ,
      fontSize: 20},
    }}
    />

       <Image
       style={styles.imageIcon}
       source={{
         uri:
        'https://www.vectorstock.com/royalty-free-vector/speaking-man-line-icon-vector-20157764' ,
       }}
       />

          <TextInput
          style={styles.inputBox}
          onChangeText={text => {
            this.setState({ text: text });
          }}
          value={this.state.text}
          />
          <TouchableOpacity
          style={styles.goButton}
          onPress={() => {
            this.setState({
              chunk: db[this.state.text].chunks });

        
          }}>
          <Text style={styles.buttonText}>GO</Text>
          </TouchableOpacity>
          <View>
          {this.state.chunks.map((items,index)=> {
            return(
              <SpeechSoundButton
              wordChunk={this.state.chunks[index]}
              soundChunk={this.state.speechSounds[index]}/>
            );
          })}
          </View>
          </View>
       );
     }
  

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ADD8E6'
  },
  inputBox: {
    marginTop: 50,
    width: '80%' ,
    alignSelf: 'center',
    height: 40,
    textAlign: 'center',
    borderWidth: 4,
    outline: 'none',
},
   goButton: {
     width: '50%',
     height: 55,
    margin: 10,
    alignSelf: 'center',
    padding: 10,
      },
      buttonText: {
        textAlign: 'center',
        fontSize: 30,
        fontWeight: 'bold',
      },

      imageIcon:{
      width: 150,
      height: 150,
      marginLeft: 95,
      },
      
});
